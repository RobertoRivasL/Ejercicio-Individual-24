import java.util.Scanner;

public class EstimadorDePi {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingresa el número de términos a utilizar:");
        int n = scanner.nextInt();
        double suma = 0;
        for (int i = 0; i < n; i++) {
            suma += Math.pow(-1, i) / (2 * i + 1);
        }
        double piEstimado = 4 * suma;
        double diferencia = Math.abs(piEstimado - Math.PI);
        System.out.println("Valor estimado de π: " + piEstimado);
        System.out.println("Diferencia con el valor real de π: " + diferencia);
    }
}